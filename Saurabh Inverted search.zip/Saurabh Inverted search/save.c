#include"is.h"

// External variables that determine if the hash table contains data
extern int flag,hash_flag;
int save_database(hash_t *hash)
{
    // Check if the hash table is empty
    if(flag != 1 && hash_flag != 1)
    {
        printf(GREEN"\nInfo : Hash table is empty to update the database\n"RESET);
        return FAILURE;
    }
    
    char file[50]; // Array to store the filename
    printf(BBLUE"Enter a file to save : "RESET);
    scanf("%s",file);

    // Validate if the entered filename has a '.txt' extension
    if(strstr(file,".txt") == NULL)
    {
        printf(RED"Error : File "GREEN" %s "RESET""RED" is not a '.txt' file\n",file);
        printf(RED"Please enter a .txt file\n");
        return FAILURE;
    }

    // Open the file in write mode
    FILE *ptr = fopen(file,"w");
    if(ptr == NULL)
    {
        printf(RED"Error : Failed to open the file "GREEN" back_up.txt "RESET"\n");
        return FAILURE;
    }

    // Iterate through the hash table and write data to the file
    for(int i=0;i<27;i++)
    {
        main_t *temp = hash[i].hash_link;  // Pointer to traverse the main linked list
        while(temp != NULL)
        {
            // Write the main entry details (index, word, file count) to the file
            fprintf(ptr,"#%d;%s;%d;",i,temp->word,temp->file_count);

            // Traverse the sub-list and write its data
            sub_t *sub_temp = temp->sub_link;
            while(sub_temp != NULL)
            {
                fprintf(ptr,"%s;%d;",sub_temp->file_name,sub_temp->word_count);
                sub_temp = sub_temp->link; // Move to the next sub-list node
            }
            fprintf(ptr,"#\n"); // Mark the end of an entry
            temp = temp->main_link; // Move to the next main list node
        }
    }
    fclose(ptr);

    printf(GREEN"\nSuccessful : Database saved in file "RED"%s\n"RESET,file);
    return SUCCESS;
}