#include "is.h"

void display(hash_t *hash)
{
    // Print the header of the display table
    printf("--------------------------------------------------------------------------------------\n");
    printf(RED" Index  Word          File Count  File Name        Word Count \n"RESET);
    printf("--------------------------------------------------------------------------------------\n");
    
    int flag = 0; // Flag to check if the hash table contains any data

    // Loop through all hash table indices (0-26)
    for (int i = 0; i < 27; i++)
    {
        // Check if the current index has any words stored
        if (hash[i].hash_link != NULL)
        {
            printf(YELLOW"  [%d]\t", i);// Print the index number
            flag = 1; // Set flag to indicate that data is present
        }

        main_t *main_temp = hash[i].hash_link; // Pointer to traverse the main linked list
        int first = 1; // Variable to manage formatting (avoiding extra tabs)
        
        // Traverse the main linked list at the current index
        while (main_temp != NULL)
        {
            if (!first) // Align formatting properly for multiple words in the same index
            {
                printf("\t");
            }

            // Print word and file count
            printf(BLUE"%-12s \t"PURPLE" %-8d "RESET, main_temp->word, main_temp->file_count);
            
            sub_t *sub_temp = main_temp->sub_link;
            int first_entry = 1; // Variable to manage formatting for sub-list entries
            
            // Traverse the sub-list (list of files where the word appears)
            while (sub_temp != NULL)
            {
                if (!first_entry)// Align formatting for subsequent sub-list entries
                {
                    printf("\n                                  ");
                }
                // Print file name and word count in that file
                printf(GREEN" %-15s "PURPLE" %-10d"RESET, sub_temp->file_name, sub_temp->word_count);
                sub_temp = sub_temp->link; // Move to the next sub-list node
                first_entry = 0; // Set flag to avoid misalignment
            }
            printf("\n");
            first = 0; // Reset first flag for main list traversal
            main_temp = main_temp->main_link;
        }
    }
    printf("--------------------------------------------------------------------------------------\n");
    if(flag == 0)
    {
        printf(RED"                            Hash table is empty                                \n"RESET);
        printf("--------------------------------------------------------------------------------------\n");
    }
}
