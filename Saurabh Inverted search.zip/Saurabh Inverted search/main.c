#include "is.h"

int main(int argc,char *argv[])
{
    hash_t hash[27]; // Declare an array of hash table structures

    // Initialize the hash table with 27 slots
    create_ht(hash,27);

    int op;

    //Initialize the single linked list head with NULL
    Slist_t *head = NULL;
    Slist_t *head2 = NULL;
    
    // Validate the input arguments and populate the linked list with file names
    if(read_and_validate(argc,argv,&head) == FAILURE)
    {
        return FAILURE;
    }

    // Infinite loop to display menu options and perform actions based on user input
    while(1)
    {
        printf(BLACK"\n1 - Create Database\n2 - Search Database\n3 - Display Database\n4 - Update Database\n5 - save Database\n6 - Exit\n");
        printf("Enter your choice : "RESET);
        __fpurge(stdin);
        scanf("%d",&op);

        switch (op)
        {
            case 1 : 
                create_database(head,hash); //Create database function calling
                break;
            case 2 : 
                search_word(hash); //Search database function calling
                break;
            case 3 : 
                display(hash); //Display database function calling
                break;
            case 4 : 
                update_database(hash,&head2); //Update database function calling
                delete_node(&head,head2);
                break;
            case 5 : 
                save_database(hash); //Save database function calling
                break;
            case 6 :
                printf(GREEN"Info : "BBLUE"Exit successfully..........\n"RESET);
                exit(0); 
            default:
                printf(RED"\nInvalid choice\n"RESET);
                break;
        }
    }

    return 0;
}