#include "is.h"
int flag,hash_flag;
int create_database(Slist_t *head,hash_t *hash)
{
    // Check if the hash table has already been created
    if(hash_flag == 1)
    {
        printf(GREEN"\nInfo : Hash tabel was already created\n"RESET);
        return SUCCESS;
    }
    // Check if the linked list is empty (i.e., no new files to process)
    if(head == NULL)
    {
        printf(RED "\nPassed files data already present in database\n");
        printf("Pass the new file to create database\n"RESET);
        return FAILURE;
    }
    
    Slist_t *file_temp = head;

    // Loop through each file in the linked list
    while(file_temp != NULL)
    {
        FILE* file = fopen(file_temp->fname,"r");
        if(file == NULL)
        {
            printf(RED"Error : Failed to open '%s' file\n",file_temp->fname);
        }
        else
        {
            char buffer[50];
            char ch;
            int i=0;

            // Read file character by character
            while((ch = fgetc(file)) != EOF)
            {
                if(ch == ' ' || ch == '\n')
                {
                    if(i>0)
                    {
                        buffer[i] = '\0';
                        insert_hash(buffer,hash,file_temp->fname); // Insert into hash table
                        i=0; // Reset buffer index
                    }
                }
                else
                {
                   buffer[i++] = ch;// Add character to buffer
                }
            }
            // Insert the last word if it exists
            if(i > 0) 
            {
                buffer[i] = '\0';
                insert_hash(buffer, hash, file_temp->fname);
            }
            fclose(file);
        }
        file_temp = file_temp->next;
    }
    hash_flag = 1;
    printf(GREEN"\nSuccessful : Database created for files - "BLUE);
    print_files(head);
    printf("\n"RESET);
    return SUCCESS;   
}


void insert_hash(char buffer[],hash_t *hash,char *file)
{
    // Calculate the hash index based on the first character of the word
    int index = tolower(buffer[0]) - 'a'; 
    if(index < 0 || index > 25)
    {
        index = 26;
    }

    // If no entry exists at this index, create a new main node
    if(hash[index].hash_link == NULL)
    {
        main_t *new = create_main(buffer, file);
        if(new == NULL)
        {
            return;
        }
        hash[index].hash_link = new;
    }
    else
    {
        main_t *temp = hash[index].hash_link;

        // Traverse the main linked list to check for an existing word
        while(temp != NULL)
        {
            if(strcmp(temp->word, buffer) == 0)
            {
                break;
            }

            if(temp->main_link == NULL)
            {
                temp->main_link = create_main(buffer, file);
                return;
            }

            temp = temp->main_link;
        }

        // Traverse the sublist (file list) to check if the word already exists in the file
        sub_t *sub_temp = temp->sub_link;
        sub_t *prev = NULL;
        int flag = 0;

        while(sub_temp != NULL)
        {
            if(strcmp(sub_temp->file_name, file) == 0)
            {
                sub_temp->word_count++; // Increment word count for this file
                flag = 1;
                break;
            }
            prev = sub_temp;
            sub_temp = sub_temp->link;
        }

         // If word was not found in the file, create a new sub node
        if(flag == 0)
        {
            temp->file_count++; // Increment file count
            sub_t *new = create_sub(file);
            if(new == NULL)
            {
                return;
            }

            // Insert sub node at the appropriate position
            if(prev == NULL)
            {
                temp->sub_link = new;
            }
            else
            {
                prev->link = new;
            }
        }
    }
}

sub_t* create_sub(char *file)
{
    sub_t *sub = malloc(sizeof(sub_t));
    if(sub == NULL)
    {
        printf(RED"Error : Failed to create sub node\n");
        return NULL;
    }

    // Initialize sub node
    sub->word_count = 1;
    strcpy(sub->file_name,file);
    sub->link = NULL;

    return sub;
}


main_t* create_main(char buffer[],char *file)
{
    main_t *new = malloc(sizeof(main_t));
    if(new == NULL)
    {
        printf(RED"Error : Failed to create main node\n");
        return NULL;
    }

    sub_t *sub = create_sub(file);
    if(sub == NULL)
    {
        return NULL;
    }

    // Initialize main node
    new->file_count = 1;
    new->main_link = NULL;
    strcpy(new->word,buffer);
    new->sub_link = sub;

    return new;
}