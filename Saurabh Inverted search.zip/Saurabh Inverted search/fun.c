#include "is.h"

void create_ht(hash_t *hash, int size)
{
    for(int i=0;i<size;i++)
    {
        hash[i].index = i;
        hash[i].hash_link = NULL;
    }
}

int read_and_validate(int argc, char *argv[],Slist_t **head)
{
    printf("\n");
    if(argc <= 1)
    {
        printf(RED"Error : Insufficient no.of command line arguments\n");
        return FAILURE;
    }

    for(int i=1;i<argc;i++)
    {
        if(strstr(argv[i],".txt") == NULL)
        {
            printf(RED"Error : File "GREEN" %s "RED" is not a '.txt' file\nPlease pass a file with .txt extension\n",argv[i]);
        }
        else
        {
            FILE* new = fopen(argv[i],"r");
            if(new == NULL)
            {
                printf(RED"Error : File "GREEN"%s "RED" is not available in the directory\nPlease pass existing file\n",argv[i]);
            }
            else{
                int count = 0;
                while(fgetc(new) != EOF)
                {
                    count++;
                }
                if(count == 0)
                {
                    printf(RED"Error : File "GREEN" %s "RED" is an empty file\nGivefiles with contents\n",argv[i]);
                }
                else{
                    Slist_t *temp = *head;
                    int flag = 0;
    
                    while(temp != NULL)
                    {
                        if(strcmp(temp->fname,argv[i]) == 0)
                        {
                            flag = 1;
                            printf(RED"Error : File"GREEN" %s "RED"is repeated\nSo we are not adding it into the list\n",argv[i]);
                            break;
                        }
                        temp = temp->next;
                    }
                    if(flag == 0)
                    {
                        printf(GREEN"Successful : File "RED"'%s'"GREEN" is added to list\n"RESET,argv[i]);
                        insert_last(head,argv[i]);
                    }
                }
            }
        }
    }
    printf("\n");
    print_slist(*head);
    return SUCCESS;
}


Slist_t* create_node(char data[])
{
    Slist_t *new = malloc(sizeof(Slist_t));
    if(new == NULL)
    {
        printf(RED"Error : Failed to create node\n");
        return FAILURE;
    }

    strcpy(new->fname,data);
    new->next = NULL;

    return new;
}

int insert_last(Slist_t **head,char data[])
{
    Slist_t *new = create_node(data);
    if(new == NULL)
    {
        return FAILURE;
    }

    if(*head == NULL)
    {
        *head = new;
    }
    else{
        Slist_t *temp = *head;

        while(temp->next != NULL)
        {
            temp = temp->next;
        }

        temp->next = new;
    }
    return SUCCESS;
}

void print_slist(Slist_t *head)
{
	if (head == NULL)
	{
		printf("INFO : List is empty\n");
	}
    else
    {
        printf(PURPLE"Head -> ");
	    while (head)		
	    {
		    printf("%s -> ", head ->fname);
		    head = head ->next;
	    }

	    printf("NULL\n"RESET);
    }
}

main_t *create_main_node(int file_count,char word[])
{
    main_t *new = malloc(sizeof(main_t));
    if(new == NULL)
    {
        return FAILURE;
    }

    new->file_count = file_count;
    strcpy(new->word,word);
    new->sub_link = NULL;
    new->main_link = NULL;

    return new;
}

sub_t *create_sub_node(int word_count,char file[])
{
    sub_t *new = malloc(sizeof(sub_t));
    if(!new)
    {
        return FAILURE;
    }
    strcpy(new->file_name,file);
    new->word_count = word_count;
    new->link = NULL;

    return new;
}

void create_list(Slist_t **head,char file[])
{
    
    Slist_t *temp = *head;
    int flag = 0;

    while(temp != NULL)
    {
        if(strcmp(temp->fname,file) == 0)
        {
            flag = 1;
            //printf(RED"Error : Duplicate "GREEN" %s "RESET""RED" file found\n",file);
            break;
        }
        temp = temp->next;
    }
    if(flag == 0)
    {
        insert_last(head,file);
    }
}

void delete_node(Slist_t **headr,Slist_t *head)
{
    Slist_t *temp1 = *headr;
    Slist_t *temp2 = head;
    Slist_t *prev = NULL;

    while(temp2 != NULL)
    {
        temp1 = *headr;
        prev = NULL;
        while(temp1 != NULL)
        {
            if(strcmp(temp1->fname,temp2->fname)==0)
            {
                if(prev == NULL)
                    *headr = temp1->next;
                else
                    prev->next = temp1->next;
            }
            prev = temp1;
            temp1 = temp1->next;
        }
        temp2 = temp2->next;
    }
    // print_slist(head);
    // print_slist(*headr);
}

void print_files(Slist_t *head)
{
    Slist_t *temp = head;
    while(temp != NULL)
    {
        printf("%s ",temp->fname);
        temp = temp->next;
    }
}