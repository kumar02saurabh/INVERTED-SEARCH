#include "is.h"

extern int hash_flag,flag;
int update_database(hash_t *hash,Slist_t **head)
{
    // Check if the database has already been created
    if(hash_flag == 1)
    {
        printf(RED"\nError : Can't update database after creating database\n"RESET);
        return FAILURE;
    }
    if(flag == 1)
    {
        printf(RED"\nDatabase already created\n");
        printf("Can't perform update database\n"RESET);
        return FAILURE;
    }

    char fname[50];

    // Prompt user to enter the backup file name
    printf(BCYAN"Enter the file name : "RESET);
    scanf("%s",fname);

    // Open the file in read mode
    FILE *ptr = fopen(fname,"r");
    if(ptr == NULL)
    {
        printf(RED"\nError : File "GREEN"%s "RESET""RED" is not available in the directory\n",fname);
        return FAILURE;
    }

    // Validate if the file has a '.txt' extension
    if(strstr(fname,".txt") == NULL)
    {
        printf(RED"\nError : File "GREEN" %s "RESET" "RED"is not a '.txt' file\n",fname);
        fclose(ptr);
        return FAILURE;
    }

    // Validate if the file is a backup file by checking the first character
    if (fgetc(ptr) != '#')
    {
        printf(RED "\nError: Input file "GREEN" %s "RESET" "RED"is not a backup file\n",fname);
        fclose(ptr);
        return FAILURE;
    }

    // Validate if the last character of the file is '#'
    fseek(ptr, -2, SEEK_END); // Move to the last character before EOF
    if (fgetc(ptr) != '#')
    {
        printf(RED "Error: Input file "GREEN" %s "RESET""RED" is not a backup file\n",fname);
        fclose(ptr);
        return FAILURE;
    }
    rewind(ptr);

    int index,file_count,word_count;
    char word[50], file[50];

    // Read the backup file and insert words into the hash table
    while(fscanf(ptr,"#%d;%[^;];%d;",&index,word,&file_count) != EOF)
    {
        main_t *main_node = create_main_node(file_count, word);
        if (!main_node)
        {
            printf(RED "Error: Memory allocation failed for main_node\n" RESET);
            fclose(ptr);
            return FAILURE;
        }
        // Insert the main node into the hash table
        if(hash[index].hash_link == NULL)
            hash[index].hash_link = main_node;
        else
        {
            main_t *temp = hash[index].hash_link;
            while(temp->main_link != NULL)
            {
                temp = temp->main_link;
            }
            temp->main_link = main_node;
        }
            

        // If the word appears in only one file, process it separately
        if(file_count == 1)
        {
            fscanf(ptr,"%[^;];%d;#\n",file,&word_count);
            sub_t *sub = create_sub_node(word_count,file);
            if (!sub)
            {
                printf(RED "Error: Memory allocation failed for sub_node\n" RESET);
                fclose(ptr);
                return FAILURE;
            }
            main_node->sub_link = sub;
            create_list(head,file);
        }
        else
        {
            sub_t *prev_sub = NULL;
            // Read multiple file records for the word
            for(int i=0;i<file_count;i++)
            {
                if(i==file_count-1)
                    fscanf(ptr,"%[^;];%d;#\n",file,&word_count);
                else
                    fscanf(ptr,"%[^;];%d;",file,&word_count);

                sub_t *sub = create_sub_node(word_count,file);
                if (!sub)
                {
                    printf(RED "Error: Memory allocation failed for sub_node\n" RESET);
                    fclose(ptr);
                    return FAILURE;
                }
                if(i==0)
                    main_node->sub_link = sub;
                else
                    prev_sub->link = sub;

                prev_sub = sub;
                create_list(head,file);
            }
        }
    }
    printf("\n");
    print_slist(*head);// Print the list of files added to the database
    printf(GREEN"\nInfo : Database updated successfully\n"RESET);
    flag = 1;  // Mark that the database has been created

    return SUCCESS;
    
}