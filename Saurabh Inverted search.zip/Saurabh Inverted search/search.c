#include "is.h"

extern int flag,hash_flag;
void search_word(hash_t *hash)
{
    // Check if the hash table has been created
    if(flag != 1 && hash_flag != 1)
    {
        printf(GREEN"\nInfo : Hash tabel is not yet created\n"RESET);
        return;
    }
    char word[50];  // Array to store the word to search

    // Prompt user for the word input
    printf("\nEnter a word to search : "RESET);
    scanf("%s",word);

    // Calculate the hash index based on the first letter of the word
    int index = tolower(word[0]) - 'a';
    if(index < 0 || index > 25) index = 26;

    // If the index does not have a linked list, the word is not found
    if(hash[index].hash_link == NULL)
    {
        printf(RED"\nWord '%s' not found\n"RESET,word);
        return;
    }

    main_t *main_temp = hash[index].hash_link;

     // Traverse the main linked list at the computed index
    while(main_temp != NULL)
    {
        // If the word matches, print the details
        if(strcmp(main_temp->word,word) == 0)
        {
            printf("\n"BLUE"'%s'"RESET" is present in "PURPLE" %d "RESET" file(s)", main_temp->word, main_temp->file_count);

            sub_t *sub_temp = main_temp->sub_link;
            while (sub_temp != NULL)
            {
                printf("\n       "GREEN"'%s' "RESET" for "CYAN"%d "RESET"time(s)", sub_temp->file_name, sub_temp->word_count);
                sub_temp = sub_temp->link; // Pointer to traverse the sub linked list
            }
            printf("\n");
            return;
        }
        main_temp = main_temp->main_link; // Move to the next main list node
    }
    printf(RED"\nWord '%s' not found\n"RESET,word);
}