#ifndef IS_H
#define IS_H

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#include<stdio_ext.h>
#include "colour.h"

#define SUCCESS 1
#define FAILURE 0

typedef struct list
{
    char fname[50];
    struct list *next;    
}Slist_t;

typedef struct node
{
    int word_count;
    char file_name[50];
    struct node *link;
}sub_t;

typedef struct main
{
    int file_count;
    char word[50];
    struct main *main_link;
    sub_t *sub_link;   
}main_t;

typedef struct hash
{
    int index;
    main_t *hash_link;
}hash_t;

int read_and_validate(int argc, char *argv[],Slist_t **head);

void create_ht(hash_t *hash, int size);
int create_database(Slist_t *head,hash_t *hash);
void insert_hash(char buffer[],hash_t *hash,char *file);

sub_t* create_sub(char *file);
main_t* create_main(char buffer[],char *file);
sub_t *create_sub_node(int word_count,char file[]);
main_t *create_main_node(int file_count,char word[]);

Slist_t* create_node(char data[]);
int insert_last(Slist_t **head,char data[]);
void print_slist(Slist_t *head);
void display(hash_t *hash);
void search_word(hash_t *hash);
int save_database(hash_t *hash);
int update_database(hash_t *hash,Slist_t **head);
void create_list(Slist_t **head,char file[]);
void delete_node(Slist_t **headr,Slist_t *head);
void print_files(Slist_t *head);

#endif